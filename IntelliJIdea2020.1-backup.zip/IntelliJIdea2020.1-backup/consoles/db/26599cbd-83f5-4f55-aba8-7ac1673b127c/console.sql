update sys_role
set remark='添加备注'
where id in (1, 2, 3);

select * from sys_role limit 0,10;

select group_concat(title),group_concat(name) from sys_role group by status;

